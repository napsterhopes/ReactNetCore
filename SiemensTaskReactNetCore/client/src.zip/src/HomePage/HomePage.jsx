import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

class HomePage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            GoldPricePerGram: '',
            WeightInGrams: '',
            DiscountPercentage:'',
            submitted: false
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        const { name, value } = e.target;
        const allowOnlyNumbersRegEx = /^[0-9\b]+$/;
        if (e.target.value === '' || allowOnlyNumbersRegEx.test(e.target.value)) {
            this.setState({ [name]: value });
        }
    }

    handleSubmit(e) {
        e.preventDefault();
     this.setState({ submitted: true });
    }

    render() {
        const { user } = this.props;
        var { GoldPricePerGram, WeightInGrams,DiscountPercentage,submitted } = this.state;
        var calcVal;
        if(!user.isPriviligedUser) {calcVal = ((GoldPricePerGram*WeightInGrams) - ((2/100)*(GoldPricePerGram*WeightInGrams)))} else {calcVal =(GoldPricePerGram*WeightInGrams)- (((DiscountPercentage/100)*(GoldPricePerGram*WeightInGrams)))};
        return (
            <div>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><Link to="/login">Login</Link> </li>
                    <li class="breadcrumb-item active">Jewelry Estimation Screen</li>
                    <h5>Welcome {user.username}!</h5>
                </ol>
                </nav>
                
                <div className="col-md-8">
                <form name="form" onSubmit={this.handleSubmit}>
                    <div className={'form-group' + (submitted && !GoldPricePerGram ? ' has-error' : '')}>
                        <label htmlFor="GoldPricePerGram">Gold Price (per gram)</label>
                        <input type="text" className="form-control" name="GoldPricePerGram" value={GoldPricePerGram} onChange={this.handleChange} />
                        {submitted && !GoldPricePerGram &&
                            <div className="help-block">Gold Price is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !WeightInGrams ? ' has-error' : '')}>
                        <label htmlFor="WeightInGrams">Weight (grams)</label>
                        <input type="WeightInGrams" className="form-control" name="WeightInGrams" value={WeightInGrams} onChange={this.handleChange} />
                        {submitted && !WeightInGrams &&
                            <div className="help-block">Weight is required</div>
                        }
                    </div>
					<div className={'form-group' + (submitted && !DiscountPercentage ? ' has-error' : '')}>
                        <label htmlFor="DiscountPercentage">Discount %  {!user.isPriviligedUser &&
                            <div className="help-block">2 for Normal User</div> 
                        }</label>
                        <input type="DiscountPercentage" className="form-control e-input" name="DiscountPercentage" onChange={this.handleChange}  disabled={!user.isPriviligedUser}/>
                        {submitted && !DiscountPercentage && user.isPriviligedUser &&
                            <div >Discount % is required</div>
                        }
                    </div>
                    <div>
                        <label htmlFor="TotalPrice">Total Price : </label> 
                          {WeightInGrams && GoldPricePerGram && calcVal}
                    </div>
                    <div className="form-group">
                        <button className="btn btn-primary" disabled={!calcVal} onClick={() => alert("Total Amount is " + calcVal)}>Print to Screen</button>
                        &nbsp; <button className="btn btn-primary" disabled={!calcVal} onClick={() => alert("Yet to be Implemented!")}>Print to File</button>
                        &nbsp; <button className="btn btn-primary" disabled={!calcVal} onClick={() => alert("Yet to be Implemented!")}>Print to Paper</button>
                    </div>
                </form>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return {
        user,
        users
    };
}

const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };