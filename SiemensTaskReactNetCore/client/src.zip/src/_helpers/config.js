export const config = {
    apiUrl: 'https://localhost:44399'
};